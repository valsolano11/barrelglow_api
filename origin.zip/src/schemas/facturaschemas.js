/* import { z } from "zod";

export const facturaschemas = z.object({
  cantidad: z.number({
    required_error: "La cantidad es requerida",
  }),
  UsuarioId: z.number({
    required_error: "El UsuarioId es obligatorio",
  }),
  detalleFacturaId: z.number({
    required_error: "El UsuarioId es obligatorio",
  }),
  metodopagoId: z.number({
    required_error: "El UsuarioId es obligatorio",
  }),
  impuestos: z.number({
    required_error: "los impuestos son requeridos",
  }),
  total: z.number({
    required_error: "los impuestos son requeridos",
  }),
});
 */